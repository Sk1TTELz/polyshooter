import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { GameServer } from "./game/game-server";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // API routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });
  
  // Get rooms list
  app.get('/api/rooms', (req, res) => {
    const gameState = require('./game/game-state').gameState;
    res.json(gameState.getRooms());
  });

  // Initialize WebSocket game server
  const gameServer = new GameServer(httpServer);
  
  // Cleanup on process exit
  process.on('SIGINT', () => {
    gameServer.cleanUp();
    process.exit();
  });

  return httpServer;
}
