import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { GameState, gameState } from './game-state';
import { 
  SocketMessageType, 
  IGameRoom, 
  GameMode, 
  Team, 
  WeaponType, 
  Vector3,
  GameStatus
} from '../../shared/game-types';
import { nanoid } from 'nanoid';

interface IWSClient extends WebSocket {
  id: string;
  username?: string;
  roomId?: string;
}

interface SocketMessage {
  type: SocketMessageType;
  payload?: any;
}

export class GameServer {
  private wss: WebSocketServer;
  private gameState: GameState;
  private clients: Map<string, IWSClient> = new Map();
  private tickInterval: NodeJS.Timeout;
  
  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/api/ws' });
    this.gameState = gameState;
    
    this.setupWebSocketEvents();
    
    // Game update tick (20 times per second)
    this.tickInterval = setInterval(() => {
      this.gameState.update();
      this.broadcastGameUpdates();
    }, 50);
  }
  
  private setupWebSocketEvents(): void {
    this.wss.on('connection', (ws: IWSClient) => {
      console.log('WebSocket connection established');
      
      // Assign unique ID to client
      ws.id = nanoid();
      this.clients.set(ws.id, ws);
      
      // Send rooms list to new client
      this.sendRoomsList(ws);
      
      ws.on('message', (data: string) => {
        try {
          const message: SocketMessage = JSON.parse(data);
          this.handleMessage(ws, message);
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
          this.sendError(ws, 'Invalid message format');
        }
      });
      
      ws.on('close', () => {
        console.log(`WebSocket connection closed for client ${ws.id}`);
        
        // Remove player from room if in one
        if (ws.roomId) {
          const updatedRoom = this.gameState.removePlayerFromRoom(ws.roomId, ws.id);
          if (updatedRoom) {
            this.broadcastToRoom(updatedRoom.id, {
              type: SocketMessageType.ROOM_UPDATE,
              payload: updatedRoom
            });
          }
        }
        
        // Remove client from list
        this.clients.delete(ws.id);
      });
    });
  }
  
  private handleMessage(client: IWSClient, message: SocketMessage): void {
    if (!message.type) {
      return this.sendError(client, 'Message type is required');
    }
    
    switch (message.type) {
      case SocketMessageType.ROOMS_LIST:
        // Client is requesting the rooms list
        this.sendRoomsList(client);
        break;
        
      case SocketMessageType.CREATE_ROOM:
        this.handleCreateRoom(client, message.payload);
        break;
        
      case SocketMessageType.JOIN_ROOM:
        this.handleJoinRoom(client, message.payload);
        break;
        
      case SocketMessageType.LEAVE_ROOM:
        this.handleLeaveRoom(client);
        break;
        
      case SocketMessageType.PLAYER_MOVE:
        this.handlePlayerMove(client, message.payload);
        break;
        
      case SocketMessageType.PLAYER_ROTATE:
        this.handlePlayerRotate(client, message.payload);
        break;
        
      case SocketMessageType.PLAYER_SHOOT:
        this.handlePlayerShoot(client, message.payload);
        break;
        
      case SocketMessageType.PLAYER_RELOAD:
        this.handlePlayerReload(client);
        break;
        
      case SocketMessageType.PLAYER_SWITCH_WEAPON:
        this.handlePlayerSwitchWeapon(client, message.payload);
        break;
        
      case SocketMessageType.CHANGE_TEAM:
        this.handleChangeTeam(client, message.payload);
        break;
        
      case SocketMessageType.START_GAME:
        this.handleStartGame(client);
        break;
        
      case SocketMessageType.END_GAME:
        this.handleEndGame(client);
        break;
        
      default:
        this.sendError(client, `Unknown message type: ${message.type}`);
    }
  }
  
  private handleCreateRoom(client: IWSClient, payload: any): void {
    if (!payload || !payload.name || !payload.mode || !payload.username) {
      return this.sendError(client, 'Invalid room creation parameters');
    }
    
    const { name, mode, username } = payload;
    
    // Set username for client
    client.username = username;
    
    // Create new room
    const room = this.gameState.createRoom(name, mode, client.id, username);
    
    // Set client's room ID
    client.roomId = room.id;
    
    // Send confirmation to client
    this.sendToClient(client, {
      type: SocketMessageType.ROOM_JOINED,
      payload: {
        room,
        playerId: client.id
      }
    });
    
    // Broadcast updated rooms list to all clients in lobby
    this.broadcastRoomsList();
  }
  
  private handleJoinRoom(client: IWSClient, payload: any): void {
    if (!payload || !payload.roomId || !payload.username) {
      return this.sendError(client, 'Invalid join room parameters');
    }
    
    const { roomId, username } = payload;
    
    // Set username for client
    client.username = username;
    
    // Try to add player to room
    const room = this.gameState.addPlayerToRoom(roomId, client.id, username);
    
    if (!room) {
      return this.sendError(client, 'Failed to join room: Room not found or full');
    }
    
    // Set client's room ID
    client.roomId = room.id;
    
    // Send confirmation to client
    this.sendToClient(client, {
      type: SocketMessageType.ROOM_JOINED,
      payload: {
        room,
        playerId: client.id
      }
    });
    
    // Broadcast room update to all clients in the room
    this.broadcastToRoom(room.id, {
      type: SocketMessageType.ROOM_UPDATE,
      payload: room
    });
    
    // Broadcast updated rooms list to all clients in lobby
    this.broadcastRoomsList();
  }
  
  private handleLeaveRoom(client: IWSClient): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    const roomId = client.roomId;
    
    // Remove player from room
    const updatedRoom = this.gameState.removePlayerFromRoom(roomId, client.id);
    
    // Clear client's room ID
    client.roomId = undefined;
    
    // Send confirmation to client
    this.sendToClient(client, {
      type: SocketMessageType.ROOMS_LIST,
      payload: this.gameState.getRooms()
    });
    
    // If room still exists, broadcast update to remaining clients
    if (updatedRoom) {
      this.broadcastToRoom(updatedRoom.id, {
        type: SocketMessageType.ROOM_UPDATE,
        payload: updatedRoom
      });
    }
    
    // Broadcast updated rooms list to all clients in lobby
    this.broadcastRoomsList();
  }
  
  private handlePlayerMove(client: IWSClient, payload: any): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    if (!payload || !payload.position || !payload.rotation) {
      return this.sendError(client, 'Invalid move parameters');
    }
    
    const { position, rotation } = payload;
    
    // Update player position and rotation
    this.gameState.movePlayer(client.roomId, client.id, position, rotation);
    
    // No need to broadcast immediately, will be included in the next tick update
  }
  
  private handlePlayerRotate(client: IWSClient, payload: any): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    if (!payload || payload.rotation === undefined) {
      return this.sendError(client, 'Invalid rotation parameter');
    }
    
    const room = this.gameState.getRoom(client.roomId);
    if (!room || !room.players[client.id]) return;
    
    // Update player rotation only
    room.players[client.id].rotation = payload.rotation;
    
    // No need to broadcast immediately, will be included in the next tick update
  }
  
  private handlePlayerShoot(client: IWSClient, payload: any): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    if (!payload || !payload.position || !payload.direction) {
      return this.sendError(client, 'Invalid shoot parameters');
    }
    
    const { position, direction } = payload;
    
    // Create bullet
    const updatedRoom = this.gameState.playerShoot(client.roomId, client.id, position, direction);
    
    if (updatedRoom) {
      // Broadcast updated bullets to room immediately
      this.broadcastToRoom(updatedRoom.id, {
        type: SocketMessageType.ROOM_UPDATE,
        payload: updatedRoom
      });
    }
  }
  
  private handlePlayerReload(client: IWSClient): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    // Start reloading
    const updatedRoom = this.gameState.playerReload(client.roomId, client.id);
    
    if (updatedRoom) {
      // Broadcast the reload state to everyone in the room
      this.broadcastToRoom(updatedRoom.id, {
        type: SocketMessageType.ROOM_UPDATE,
        payload: updatedRoom
      });
    }
  }
  
  private handlePlayerSwitchWeapon(client: IWSClient, payload: any): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    if (!payload || payload.weaponType === undefined) {
      return this.sendError(client, 'Invalid weapon parameter');
    }
    
    // Switch weapon
    const updatedRoom = this.gameState.playerSwitchWeapon(client.roomId, client.id, payload.weaponType);
    
    if (updatedRoom) {
      // Broadcast weapon change
      this.broadcastToRoom(updatedRoom.id, {
        type: SocketMessageType.ROOM_UPDATE,
        payload: updatedRoom
      });
    }
  }
  
  private handleChangeTeam(client: IWSClient, payload: any): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    if (!payload || payload.team === undefined) {
      return this.sendError(client, 'Invalid team parameter');
    }
    
    // Change team
    const updatedRoom = this.gameState.changePlayerTeam(client.roomId, client.id, payload.team);
    
    if (updatedRoom) {
      // Broadcast team change
      this.broadcastToRoom(updatedRoom.id, {
        type: SocketMessageType.ROOM_UPDATE,
        payload: updatedRoom
      });
    }
  }
  
  private handleStartGame(client: IWSClient): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    console.log(`Client ${client.id} (${client.username}) attempting to start game in room ${client.roomId}`);
    
    // Get the room
    const room = this.gameState.getRoom(client.roomId);
    if (!room) {
      return this.sendError(client, 'Room not found');
    }
    
    // Simplified check: allow starting with just one player for testing
    // (original code would require at least 2 players)
    if (Object.keys(room.players).length < 1) {
      console.log(`Failed to start game in room ${client.roomId}: Not enough players`);
      return this.sendError(client, 'Failed to start game: Need at least 1 player');
    }
    
    // Update room status manually for testing
    room.status = GameStatus.PLAYING;
    
    console.log(`Game started in room ${client.roomId}. Status: ${room.status}`);
    
    // Broadcast game started to ALL clients in the room
    this.clients.forEach(c => {
      if (c.roomId === client.roomId) {
        console.log(`Sending GAME_STARTED to client ${c.id} (${c.username})`);
        this.sendToClient(c, {
          type: SocketMessageType.GAME_STARTED,
          payload: room
        });
      }
    });
    
    // Broadcast updated rooms list to all clients in lobby
    this.broadcastRoomsList();
  }
  
  private handleEndGame(client: IWSClient): void {
    if (!client.roomId) {
      return this.sendError(client, 'Not in a room');
    }
    
    // End game
    const updatedRoom = this.gameState.endGame(client.roomId);
    
    if (updatedRoom) {
      // Broadcast game ended
      this.broadcastToRoom(updatedRoom.id, {
        type: SocketMessageType.GAME_ENDED,
        payload: updatedRoom
      });
      
      // Broadcast updated rooms list to all clients in lobby
      this.broadcastRoomsList();
    }
  }
  
  private sendRoomsList(client: IWSClient): void {
    this.sendToClient(client, {
      type: SocketMessageType.ROOMS_LIST,
      payload: this.gameState.getRooms()
    });
  }
  
  private broadcastRoomsList(): void {
    const rooms = this.gameState.getRooms();
    
    // Send to all clients that are not in a room
    this.clients.forEach(client => {
      if (!client.roomId) {
        this.sendToClient(client, {
          type: SocketMessageType.ROOMS_LIST,
          payload: rooms
        });
      }
    });
  }
  
  private broadcastGameUpdates(): void {
    // For each room, send updates to all players in that room
    this.gameState.getRooms().forEach(room => {
      if (room.status === 'PLAYING') {
        this.broadcastToRoom(room.id, {
          type: SocketMessageType.ROOM_UPDATE,
          payload: room
        });
      }
    });
  }
  
  private broadcastToRoom(roomId: string, message: SocketMessage): void {
    this.clients.forEach(client => {
      if (client.roomId === roomId) {
        this.sendToClient(client, message);
      }
    });
  }
  
  private sendToClient(client: IWSClient, message: SocketMessage): void {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  }
  
  private sendError(client: IWSClient, message: string): void {
    this.sendToClient(client, {
      type: SocketMessageType.ERROR,
      payload: { message }
    });
  }
  
  public cleanUp(): void {
    clearInterval(this.tickInterval);
    this.wss.close();
  }
}
