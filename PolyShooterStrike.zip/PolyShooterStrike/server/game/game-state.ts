import { 
  IGameRoom, 
  IPlayer, 
  IBullet, 
  GameMode, 
  GameStatus, 
  Team, 
  WeaponType,
  CONSTANTS, 
  Vector3 
} from '../../shared/game-types';
import { nanoid } from 'nanoid';

// Utility function to get a random position in the arena
const getRandomPosition = (): Vector3 => {
  const mapSize = CONSTANTS.MAP_SIZE;
  // Keep player off the edges
  const margin = 5;
  return {
    x: Math.random() * (mapSize - 2 * margin) - (mapSize / 2) + margin,
    y: 1, // Player height
    z: Math.random() * (mapSize - 2 * margin) - (mapSize / 2) + margin
  };
};

// Utility to calculate distance between positions
const getDistance = (pos1: Vector3, pos2: Vector3): number => {
  return Math.sqrt(
    Math.pow(pos2.x - pos1.x, 2) + 
    Math.pow(pos2.y - pos1.y, 2) + 
    Math.pow(pos2.z - pos1.z, 2)
  );
};

export class GameState {
  private rooms: Map<string, IGameRoom>;

  constructor() {
    this.rooms = new Map();
  }

  // Get all game rooms
  public getRooms(): IGameRoom[] {
    return Array.from(this.rooms.values());
  }

  // Get a specific room by ID
  public getRoom(roomId: string): IGameRoom | undefined {
    return this.rooms.get(roomId);
  }

  // Create a new game room
  public createRoom(name: string, mode: GameMode, creatorId: string, creatorName: string): IGameRoom {
    const roomId = nanoid(10);
    const initialPlayer: IPlayer = {
      id: creatorId,
      username: creatorName,
      position: getRandomPosition(),
      rotation: 0,
      health: CONSTANTS.MAX_HEALTH,
      team: mode === GameMode.TEAM_DEATHMATCH ? Team.RED : Team.NONE,
      currentWeapon: WeaponType.PISTOL,
      score: 0,
      isAlive: true,
      isReloading: false,
      lastShootTime: 0
    };
    
    const room: IGameRoom = {
      id: roomId,
      name,
      mode,
      status: GameStatus.LOBBY,
      players: { [creatorId]: initialPlayer },
      bullets: [],
      maxPlayers: 10,
      createdAt: Date.now(),
      teams: mode === GameMode.TEAM_DEATHMATCH 
        ? { [Team.RED]: [creatorId], [Team.BLUE]: [] } 
        : undefined
    };
    
    this.rooms.set(roomId, room);
    return room;
  }

  // Add a player to a room
  public addPlayerToRoom(roomId: string, playerId: string, playerName: string): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    // Check if room is full
    if (Object.keys(room.players).length >= room.maxPlayers) {
      return undefined;
    }
    
    const newPlayer: IPlayer = {
      id: playerId,
      username: playerName,
      position: getRandomPosition(),
      rotation: 0,
      health: CONSTANTS.MAX_HEALTH,
      team: room.mode === GameMode.TEAM_DEATHMATCH ? this.getSmallestTeam(room) : Team.NONE,
      currentWeapon: WeaponType.PISTOL,
      score: 0,
      isAlive: true,
      isReloading: false,
      lastShootTime: 0
    };
    
    room.players[playerId] = newPlayer;
    
    // Add player to team if team mode
    if (room.mode === GameMode.TEAM_DEATHMATCH && room.teams) {
      room.teams[newPlayer.team].push(playerId);
    }
    
    return room;
  }

  // Remove a player from a room
  public removePlayerFromRoom(roomId: string, playerId: string): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    // Remove from teams if applicable
    if (room.mode === GameMode.TEAM_DEATHMATCH && room.teams && room.players[playerId]) {
      const playerTeam = room.players[playerId].team;
      room.teams[playerTeam] = room.teams[playerTeam].filter(id => id !== playerId);
    }
    
    // Remove player
    delete room.players[playerId];
    
    // Delete room if empty
    if (Object.keys(room.players).length === 0) {
      this.rooms.delete(roomId);
      return undefined;
    }
    
    return room;
  }

  // Change a player's team
  public changePlayerTeam(roomId: string, playerId: string, team: Team): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room || room.mode !== GameMode.TEAM_DEATHMATCH || !room.teams) return undefined;
    
    const player = room.players[playerId];
    if (!player) return undefined;
    
    // Remove from old team
    room.teams[player.team] = room.teams[player.team].filter(id => id !== playerId);
    
    // Add to new team
    room.teams[team].push(playerId);
    player.team = team;
    
    return room;
  }

  // Start a game
  public startGame(roomId: string): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    // Make sure there are at least 2 players
    if (Object.keys(room.players).length < 2) {
      return undefined;
    }
    
    // For team mode, ensure there's at least one player on each team
    if (room.mode === GameMode.TEAM_DEATHMATCH && room.teams) {
      if (room.teams[Team.RED].length === 0 || room.teams[Team.BLUE].length === 0) {
        return undefined;
      }
    }
    
    // Reset all players
    Object.values(room.players).forEach(player => {
      player.position = getRandomPosition();
      player.health = CONSTANTS.MAX_HEALTH;
      player.score = 0;
      player.isAlive = true;
    });
    
    room.status = GameStatus.PLAYING;
    room.bullets = [];
    
    return room;
  }

  // End a game
  public endGame(roomId: string): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    room.status = GameStatus.ENDED;
    return room;
  }

  // Player movement
  public movePlayer(roomId: string, playerId: string, position: Vector3, rotation: number): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    const player = room.players[playerId];
    if (!player) return undefined;
    
    player.position = position;
    player.rotation = rotation;
    
    return room;
  }

  // Player shoots
  public playerShoot(roomId: string, playerId: string, position: Vector3, direction: Vector3): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room || room.status !== GameStatus.PLAYING) return undefined;
    
    const player = room.players[playerId];
    if (!player || !player.isAlive || player.isReloading) return undefined;
    
    const weapon = CONSTANTS.WEAPONS[player.currentWeapon];
    const now = Date.now();
    
    // Check if player can shoot (fireRate)
    if (now - player.lastShootTime < 1000 / weapon.fireRate) {
      return undefined;
    }
    
    // Create bullet
    const bulletId = nanoid();
    
    // Apply some spread to the direction
    const spread = weapon.spread;
    const newDirection = {
      x: direction.x + (Math.random() * 2 - 1) * spread,
      y: direction.y + (Math.random() * 2 - 1) * spread,
      z: direction.z + (Math.random() * 2 - 1) * spread,
    };
    
    // Normalize the direction
    const magnitude = Math.sqrt(
      newDirection.x * newDirection.x + 
      newDirection.y * newDirection.y + 
      newDirection.z * newDirection.z
    );
    
    const normalizedDirection = {
      x: newDirection.x / magnitude,
      y: newDirection.y / magnitude,
      z: newDirection.z / magnitude,
    };
    
    const bullet: IBullet = {
      id: bulletId,
      position: { ...position },
      direction: normalizedDirection,
      speed: weapon.bulletSpeed,
      ownerId: playerId,
      damage: weapon.damage,
      weaponType: player.currentWeapon,
      createdAt: now
    };
    
    room.bullets.push(bullet);
    player.lastShootTime = now;
    
    return room;
  }

  // Player reload
  public playerReload(roomId: string, playerId: string): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    const player = room.players[playerId];
    if (!player || !player.isAlive) return undefined;
    
    player.isReloading = true;
    
    // Schedule the end of reload
    setTimeout(() => {
      if (this.rooms.has(roomId) && this.rooms.get(roomId)?.players[playerId]) {
        this.rooms.get(roomId)!.players[playerId].isReloading = false;
      }
    }, CONSTANTS.WEAPONS[player.currentWeapon].reloadTime * 1000);
    
    return room;
  }

  // Player switch weapon
  public playerSwitchWeapon(roomId: string, playerId: string, weaponType: WeaponType): IGameRoom | undefined {
    const room = this.rooms.get(roomId);
    if (!room) return undefined;
    
    const player = room.players[playerId];
    if (!player || !player.isAlive) return undefined;
    
    player.currentWeapon = weaponType;
    return room;
  }

  // Update game state (called on server tick)
  public update(): void {
    const now = Date.now();
    
    this.rooms.forEach(room => {
      if (room.status !== GameStatus.PLAYING) return;
      
      // Update bullets
      const bullets = room.bullets;
      const updatedBullets: IBullet[] = [];
      
      for (const bullet of bullets) {
        // Check if bullet is expired
        if (now - bullet.createdAt > CONSTANTS.BULLET_LIFETIME) {
          continue;
        }
        
        // Move bullet
        bullet.position = {
          x: bullet.position.x + bullet.direction.x * bullet.speed * 0.1, // Scaling for time delta
          y: bullet.position.y + bullet.direction.y * bullet.speed * 0.1,
          z: bullet.position.z + bullet.direction.z * bullet.speed * 0.1
        };
        
        // Check collisions with players
        let hitPlayer = false;
        
        Object.values(room.players).forEach(player => {
          if (!player.isAlive || player.id === bullet.ownerId) return;
          
          // Skip if same team in team deathmatch
          if (room.mode === GameMode.TEAM_DEATHMATCH && 
              room.players[bullet.ownerId] && 
              room.players[bullet.ownerId].team === player.team) {
            return;
          }
          
          // Simple collision detection (player is a sphere with radius 1)
          const distance = getDistance(bullet.position, player.position);
          if (distance < 1) { // Player hit radius
            hitPlayer = true;
            
            // Apply damage
            player.health -= bullet.damage;
            
            // Check if player died
            if (player.health <= 0) {
              player.health = 0;
              player.isAlive = false;
              
              // Award score to shooter
              if (room.players[bullet.ownerId]) {
                room.players[bullet.ownerId].score += 1;
              }
              
              // Schedule respawn
              setTimeout(() => {
                if (this.rooms.has(room.id) && this.rooms.get(room.id)?.players[player.id]) {
                  const player = this.rooms.get(room.id)!.players[player.id];
                  player.health = CONSTANTS.MAX_HEALTH;
                  player.isAlive = true;
                  player.position = getRandomPosition();
                }
              }, CONSTANTS.RESPAWN_TIME);
            }
          }
        });
        
        // Add bullet to updated list if it didn't hit anything
        if (!hitPlayer) {
          updatedBullets.push(bullet);
        }
      }
      
      room.bullets = updatedBullets;
    });
  }

  // Helper to determine which team has fewer players
  private getSmallestTeam(room: IGameRoom): Team {
    if (!room.teams) return Team.NONE;
    return room.teams[Team.RED].length <= room.teams[Team.BLUE].length ? Team.RED : Team.BLUE;
  }
}

export const gameState = new GameState();
