import { create } from "zustand";
import { SocketMessageType, GameStatus, GameMode, IGameRoom } from "@shared/game-types";
import { useSocketConnection } from "./useSocketConnection";

interface GameState {
  status: GameStatus;
  roomsList: IGameRoom[];
  currentRoom: IGameRoom | null;
  playerId: string | null;
  isLoading: boolean;
  
  // Actions
  setRoomsList: (rooms: IGameRoom[]) => void;
  setCurrentRoom: (room: IGameRoom | null) => void;
  setPlayerId: (id: string | null) => void;
  setGameStatus: (status: GameStatus) => void;
  setIsLoading: (isLoading: boolean) => void;
  
  // Game functions
  fetchRooms: () => void;
  createRoom: (name: string, mode: GameMode, username: string) => void;
  joinRoom: (roomId: string, username: string) => void;
  returnToLobby: () => void;
}

export const useGameState = create<GameState>((set, get) => ({
  status: GameStatus.LOBBY,
  roomsList: [],
  currentRoom: null,
  playerId: null,
  isLoading: false,
  
  setRoomsList: (rooms) => set({ roomsList: rooms }),
  setCurrentRoom: (room) => set({ currentRoom: room }),
  setPlayerId: (id) => set({ playerId: id }),
  setGameStatus: (status) => set({ status }),
  setIsLoading: (isLoading) => set({ isLoading }),
  
  fetchRooms: async () => {
    const socket = useSocketConnection.getState().socket;
    
    if (socket) {
      // Using WebSocket to get rooms list
      socket.send(JSON.stringify({
        type: SocketMessageType.ROOMS_LIST
      }));
    }
  },
  
  createRoom: (name, mode, username) => {
    set({ isLoading: true });
    const socket = useSocketConnection.getState().socket;
    
    if (socket) {
      socket.send(JSON.stringify({
        type: SocketMessageType.CREATE_ROOM,
        payload: {
          name,
          mode,
          username
        }
      }));
    }
  },
  
  joinRoom: (roomId, username) => {
    set({ isLoading: true });
    const socket = useSocketConnection.getState().socket;
    
    if (socket) {
      socket.send(JSON.stringify({
        type: SocketMessageType.JOIN_ROOM,
        payload: {
          roomId,
          username
        }
      }));
    }
  },
  
  returnToLobby: () => {
    set({ status: GameStatus.LOBBY });
    get().fetchRooms();
  }
}));

// Set up socket message handlers
export function setupGameStateSocketHandlers(socket: WebSocket) {
  socket.addEventListener("message", (event) => {
    try {
      const message = JSON.parse(event.data);
      
      switch (message.type) {
        case SocketMessageType.ROOMS_LIST:
          useGameState.getState().setRoomsList(message.payload || []);
          break;
          
        case SocketMessageType.ROOM_JOINED:
          useGameState.getState().setCurrentRoom(message.payload.room);
          useGameState.getState().setPlayerId(message.payload.playerId);
          useGameState.getState().setGameStatus(GameStatus.LOBBY);
          useGameState.getState().setIsLoading(false);
          break;
          
        case SocketMessageType.ROOM_UPDATE:
          useGameState.getState().setCurrentRoom(message.payload);
          break;
          
        case SocketMessageType.GAME_STARTED:
          console.log("GAME_STARTED message received!", message.payload);
          
          // First update the game status to trigger UI changes
          useGameState.getState().setGameStatus(GameStatus.PLAYING);
          
          // Then update the room
          setTimeout(() => {
            useGameState.getState().setCurrentRoom(message.payload);
            console.log("Game state updated to PLAYING with room:", message.payload);
          }, 100);
          break;
          
        case SocketMessageType.GAME_ENDED:
          useGameState.getState().setCurrentRoom(message.payload);
          useGameState.getState().setGameStatus(GameStatus.ENDED);
          break;
          
        case SocketMessageType.ERROR:
          console.error("Socket error:", message.payload.message);
          useGameState.getState().setIsLoading(false);
          alert(`Error: ${message.payload.message}`);
          break;
      }
    } catch (error) {
      console.error("Error parsing socket message:", error);
    }
  });
}
