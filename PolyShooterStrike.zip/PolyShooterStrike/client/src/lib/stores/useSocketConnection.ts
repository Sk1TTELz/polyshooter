import { create } from "zustand";
import { setupGameStateSocketHandlers } from "./useGameState";

interface SocketState {
  socket: WebSocket | null;
  isConnected: boolean;
  connectSocket: () => void;
  disconnectSocket: () => void;
  reconnectSocket: () => void;
}

export const useSocketConnection = create<SocketState>((set, get) => ({
  socket: null,
  isConnected: false,
  
  connectSocket: () => {
    const { socket } = get();
    
    // If already connected, do nothing
    if (socket && socket.readyState === WebSocket.OPEN) {
      return;
    }
    
    // Close existing socket if any
    if (socket) {
      socket.close();
    }
    
    // Determine WebSocket URL based on current location
    const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
    // For Replit environment, use the same host as the current window
    const wsUrl = `${protocol}://${window.location.host}/api/ws`;
    
    console.log("Connecting to WebSocket at:", wsUrl);
    
    // Create new WebSocket connection
    const newSocket = new WebSocket(wsUrl);
    
    // Set a longer timeout for the WebSocket connection
    newSocket.onclose = (event) => {
      console.log('WebSocket connection closed', event.code, event.reason);
      set({ isConnected: false });
      
      // Attempt to reconnect after a brief delay if it was an abnormal closure
      if (event.code !== 1000 && event.code !== 1001) {
        console.log('Attempting to reconnect in 3 seconds...');
        setTimeout(() => {
          get().connectSocket();
        }, 3000);
      }
    };
    
    newSocket.addEventListener('open', () => {
      console.log('WebSocket connection established');
      set({ isConnected: true });
      
      // Check URL for room ID query parameter
      const urlParams = new URLSearchParams(window.location.search);
      const roomId = urlParams.get('room');
      
      // If room ID exists, automatically try to join that room
      if (roomId) {
        // Get username from localStorage or generate a random one
        const username = localStorage.getItem('username') || `Player${Math.floor(Math.random() * 1000)}`;
        
        // Send join room message
        newSocket.send(JSON.stringify({
          type: 'JOIN_ROOM',
          payload: {
            roomId,
            username
          }
        }));
        
        // Clear the URL parameter
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    });
    
    // We already set onclose handler above, so we don't need this additional event listener
    
    newSocket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
      set({ isConnected: false });
    });
    
    // Setup game state handlers for this socket
    setupGameStateSocketHandlers(newSocket);
    
    set({ socket: newSocket });
  },
  
  disconnectSocket: () => {
    const { socket } = get();
    
    if (socket) {
      socket.close();
      set({ socket: null, isConnected: false });
    }
  },
  
  reconnectSocket: () => {
    const { socket } = get();
    
    // First try to close current socket if it exists
    if (socket) {
      try {
        socket.close();
      } catch (e) {
        console.warn("Error closing socket during reconnect:", e);
      }
    }
    
    // Clear current socket state
    set({ socket: null, isConnected: false });
    
    // Then reconnect after a short delay
    console.log("Preparing to reconnect...");
    setTimeout(() => {
      console.log("Reconnecting now...");
      get().connectSocket();
    }, 500);
  }
}));
