import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { WeaponType, Vector3, SocketMessageType, CONSTANTS } from "@shared/game-types";
import { useAudio } from "./useAudio";
import { useSocketConnection } from "./useSocketConnection";

interface PlayerState {
  playerId: string | null;
  roomId: string | null;
  position: Vector3;
  velocity: number;
  isGrounded: boolean;
  selectedWeaponIndex: number;
  weaponTypes: WeaponType[];
  ammo: number;
  maxAmmo: number;
  isReloading: boolean;
  lastShootTime: number;
  socketConnection: WebSocket | null;
  
  // Actions
  initialize: (params: {
    playerId: string;
    roomId: string;
    position: Vector3;
    weaponType: WeaponType;
  }) => void;
  setPosition: (position: Vector3) => void;
  setVelocity: (velocity: number) => void;
  setGrounded: (isGrounded: boolean) => void;
  setSocketConnection: (socket: WebSocket | null) => void;
  
  // Gameplay functions
  shoot: () => void;
  reload: () => void;
  changeWeapon: (index: number) => void;
  reset: () => void;
}

export const usePlayerState = create<PlayerState>()(
  subscribeWithSelector((set, get) => ({
    playerId: null,
    roomId: null,
    position: { x: 0, y: 1, z: 0 },
    velocity: 0,
    isGrounded: true,
    selectedWeaponIndex: 0,
    weaponTypes: [WeaponType.PISTOL, WeaponType.RIFLE, WeaponType.SHOTGUN],
    ammo: 8, // Default pistol ammo
    maxAmmo: 8,
    isReloading: false,
    lastShootTime: 0,
    socketConnection: null,
    
    initialize: ({ playerId, roomId, position, weaponType }) => {
      // Calculate weapon index
      const weaponTypes = [WeaponType.PISTOL, WeaponType.RIFLE, WeaponType.SHOTGUN];
      const weaponIndex = weaponTypes.indexOf(weaponType);
      
      // Set weapon stats
      const weaponStats = CONSTANTS.WEAPONS[weaponType];
      
      // Get socket from the connection store
      const socketConnection = useSocketConnection.getState().socket;
      
      set({
        playerId,
        roomId,
        position,
        socketConnection,
        selectedWeaponIndex: weaponIndex >= 0 ? weaponIndex : 0,
        ammo: weaponStats.ammoCapacity,
        maxAmmo: weaponStats.ammoCapacity,
        isReloading: false,
        lastShootTime: 0,
        velocity: 0,
        isGrounded: true
      });
      
      console.log("Player state initialized with weapon:", weaponType);
    },
    
    setPosition: (position) => set({ position }),
    
    setVelocity: (velocity) => set({ velocity }),
    
    setGrounded: (isGrounded) => set({ isGrounded }),
    
    setSocketConnection: (socketConnection) => set({ socketConnection }),
    
    shoot: () => {
      const { 
        playerId, 
        roomId, 
        position, 
        isReloading, 
        lastShootTime, 
        ammo, 
        selectedWeaponIndex, 
        weaponTypes 
      } = get();
      
      if (!playerId || !roomId || isReloading || ammo <= 0) {
        return;
      }
      
      const weaponType = weaponTypes[selectedWeaponIndex];
      const weaponStats = CONSTANTS.WEAPONS[weaponType];
      
      // Check fire rate
      const now = Date.now();
      if (now - lastShootTime < 1000 / weaponStats.fireRate) {
        return;
      }
      
      // Get socket from the connection store
      const socket = get().socketConnection;
      if (!socket) return;
      
      // Calculate shooting direction based on camera
      // In a real implementation, we'd get this from the actual camera
      // Here we're shooting straight ahead
      const direction = { x: 0, y: 0, z: -1 };
      
      // Send shoot message to server
      socket.send(JSON.stringify({
        type: SocketMessageType.PLAYER_SHOOT,
        payload: {
          position,
          direction
        }
      }));
      
      // Update state
      set({ 
        ammo: ammo - 1,
        lastShootTime: now
      });
      
      // Play sound
      useAudio.getState().playHit();
      
      // Auto reload if out of ammo
      if (ammo - 1 <= 0) {
        get().reload();
      }
    },
    
    reload: () => {
      const { isReloading, ammo, maxAmmo, playerId, roomId } = get();
      
      if (!playerId || !roomId || isReloading || ammo >= maxAmmo) {
        return;
      }
      
      // Get socket from the connection store
      const socket = get().socketConnection;
      if (!socket) return;
      
      // Send reload message to server
      socket.send(JSON.stringify({
        type: SocketMessageType.PLAYER_RELOAD
      }));
      
      // Start reloading
      set({ isReloading: true });
      
      // Get weapon type and reload time
      const weaponType = get().weaponTypes[get().selectedWeaponIndex];
      const reloadTime = CONSTANTS.WEAPONS[weaponType].reloadTime * 1000;
      
      // Play sound
      setTimeout(() => {
        useAudio.getState().playSuccess();
      }, reloadTime / 2);
      
      // Finish reloading after reload time
      setTimeout(() => {
        set({ 
          isReloading: false,
          ammo: get().maxAmmo 
        });
      }, reloadTime);
    },
    
    changeWeapon: (index) => {
      const { weaponTypes, isReloading, playerId, roomId } = get();
      
      if (!playerId || !roomId || isReloading || index < 0 || index >= weaponTypes.length) {
        return;
      }
      
      // Get socket from the connection store
      const socket = get().socketConnection;
      if (!socket) return;
      
      const weaponType = weaponTypes[index];
      
      // Send weapon change message to server
      socket.send(JSON.stringify({
        type: SocketMessageType.PLAYER_SWITCH_WEAPON,
        payload: {
          weaponType
        }
      }));
      
      // Update state
      const weaponStats = CONSTANTS.WEAPONS[weaponType];
      set({ 
        selectedWeaponIndex: index,
        ammo: weaponStats.ammoCapacity,
        maxAmmo: weaponStats.ammoCapacity
      });
    },
    
    reset: () => {
      set({
        playerId: null,
        roomId: null,
        position: { x: 0, y: 1, z: 0 },
        velocity: 0,
        isGrounded: true,
        selectedWeaponIndex: 0,
        weaponTypes: [WeaponType.PISTOL, WeaponType.RIFLE, WeaponType.SHOTGUN],
        ammo: 8,
        maxAmmo: 8,
        isReloading: false,
        lastShootTime: 0,
        socketConnection: null
      });
    }
  }))
);
