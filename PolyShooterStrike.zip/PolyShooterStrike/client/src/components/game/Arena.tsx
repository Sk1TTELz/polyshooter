import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { useMemo } from "react";
import { CONSTANTS } from "@shared/game-types";

// Arena component that creates the game environment
export default function Arena() {
  // Load textures
  const grassTexture = useTexture("/textures/grass.png");
  const woodTexture = useTexture("/textures/wood.jpg");
  const sandTexture = useTexture("/textures/sand.jpg");
  
  // Set texture repeats
  grassTexture.repeat.set(10, 10);
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  
  woodTexture.repeat.set(2, 2);
  woodTexture.wrapS = woodTexture.wrapT = THREE.RepeatWrapping;
  
  sandTexture.repeat.set(5, 5);
  sandTexture.wrapS = sandTexture.wrapT = THREE.RepeatWrapping;
  
  // Define the map size
  const mapSize = CONSTANTS.MAP_SIZE;
  
  // Create obstacles with memoization to avoid recreating them every render
  const obstacles = useMemo(() => {
    const items = [];
    const halfMapSize = mapSize / 2;
    
    // Generate boxes for cover
    for (let i = 0; i < 15; i++) {
      const boxSize = 1 + Math.random() * 2;
      const boxHeight = 1 + Math.random() * 2;
      
      // Avoid placing obstacles in the center or at spawn locations
      const minDistanceFromCenter = 8;
      
      let x, z;
      do {
        x = Math.random() * (mapSize - 4) - halfMapSize + 2;
        z = Math.random() * (mapSize - 4) - halfMapSize + 2;
      } while (Math.sqrt(x * x + z * z) < minDistanceFromCenter);
      
      items.push(
        <Box 
          key={`box-${i}`}
          position={[x, boxHeight / 2, z]}
          size={[boxSize, boxHeight, boxSize]}
          color="#8B4513"
          texture={woodTexture}
        />
      );
    }
    
    // Generate some ramps
    for (let i = 0; i < 5; i++) {
      const rampWidth = 3 + Math.random() * 2;
      const rampLength = 4 + Math.random() * 3;
      const rampHeight = 2 + Math.random() * 1.5;
      
      let x, z;
      do {
        x = Math.random() * (mapSize - rampLength - 4) - halfMapSize + 2;
        z = Math.random() * (mapSize - rampWidth - 4) - halfMapSize + 2;
      } while (Math.sqrt(x * x + z * z) < 10);
      
      // Random rotation (0, 90, 180, or 270 degrees)
      const rotation = Math.floor(Math.random() * 4) * Math.PI / 2;
      
      items.push(
        <Ramp 
          key={`ramp-${i}`}
          position={[x, 0, z]}
          size={[rampLength, rampHeight, rampWidth]}
          rotation={[0, rotation, 0]}
          color="#a9a9a9"
          texture={sandTexture}
        />
      );
    }
    
    return items;
  }, [woodTexture, sandTexture]);
  
  return (
    <group>
      {/* Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[mapSize, mapSize]} />
        <meshStandardMaterial map={grassTexture} />
      </mesh>
      
      {/* Boundary walls */}
      <Wall position={[0, 2.5, mapSize / 2]} size={[mapSize, 5, 1]} />
      <Wall position={[0, 2.5, -mapSize / 2]} size={[mapSize, 5, 1]} />
      <Wall position={[mapSize / 2, 2.5, 0]} size={[1, 5, mapSize]} />
      <Wall position={[-mapSize / 2, 2.5, 0]} size={[1, 5, mapSize]} />
      
      {/* Obstacles */}
      {obstacles}
    </group>
  );
}

// Wall component
function Wall({ position, size }: { position: [number, number, number], size: [number, number, number] }) {
  return (
    <mesh position={position} receiveShadow castShadow>
      <boxGeometry args={size} />
      <meshStandardMaterial color="#555555" />
    </mesh>
  );
}

// Box component for obstacles
function Box({ 
  position, 
  size, 
  color, 
  texture
}: { 
  position: [number, number, number], 
  size: [number, number, number], 
  color: string, 
  texture?: THREE.Texture 
}) {
  return (
    <mesh position={position} receiveShadow castShadow>
      <boxGeometry args={size} />
      <meshStandardMaterial color={color} map={texture} />
    </mesh>
  );
}

// Ramp component
function Ramp({ 
  position, 
  size, 
  rotation, 
  color, 
  texture 
}: { 
  position: [number, number, number], 
  size: [number, number, number], 
  rotation: [number, number, number], 
  color: string, 
  texture?: THREE.Texture 
}) {
  // Create a custom geometry for the ramp
  const geometry = useMemo(() => {
    const [length, height, width] = size;
    
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.lineTo(length, 0);
    shape.lineTo(length, 0);
    shape.lineTo(0, height);
    shape.lineTo(0, 0);
    
    const extrudeSettings = {
      steps: 1,
      depth: width,
      bevelEnabled: false
    };
    
    return new THREE.ExtrudeGeometry(shape, extrudeSettings);
  }, [size]);
  
  return (
    <mesh 
      position={position} 
      rotation={rotation} 
      geometry={geometry} 
      receiveShadow 
      castShadow
    >
      <meshStandardMaterial color={color} map={texture} />
    </mesh>
  );
}
