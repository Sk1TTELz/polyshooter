import { useEffect, useRef } from "react";
import { useGameState } from "../../lib/stores/useGameState";
import { usePlayerState } from "../../lib/stores/usePlayerState";
import { useSocketConnection } from "../../lib/stores/useSocketConnection";
import Player from "./Player";
import Arena from "./Arena";
import Bullet from "./Bullet";

// The main game world component that contains the environment and all game entities
export default function World() {
  const { currentRoom, playerId } = useGameState(state => ({
    currentRoom: state.currentRoom,
    playerId: state.playerId
  }));
  
  const socketConnection = useSocketConnection(state => state.socket);
  const hasInitialized = useRef(false);
  
  // Initialize player state when the room is loaded
  useEffect(() => {
    console.log("World component - currentRoom changed:", currentRoom?.id);
    console.log("World component - playerId:", playerId);
    
    if (currentRoom && playerId) {
      // Get the local player from the room
      const localPlayer = currentRoom.players[playerId];
      console.log("Local player:", localPlayer);
      
      if (localPlayer) {
        // Reset previous state if needed
        if (hasInitialized.current) {
          usePlayerState.getState().reset();
        }
        
        // Initialize player state
        usePlayerState.getState().initialize({
          playerId,
          roomId: currentRoom.id,
          position: localPlayer.position,
          weaponType: localPlayer.currentWeapon
        });
        
        // Set the socket connection separately
        usePlayerState.getState().setSocketConnection(socketConnection);
        
        hasInitialized.current = true;
        console.log("Player state initialized successfully");
      } else {
        console.error("Local player not found in room players list", currentRoom.players);
      }
    }
    
    return () => {
      if (hasInitialized.current) {
        usePlayerState.getState().reset();
        hasInitialized.current = false;
        console.log("Player state reset on unmount");
      }
    };
  }, [currentRoom, playerId, socketConnection]);
  
  // If there's no current room, don't render anything
  if (!currentRoom) {
    return null;
  }
  
  // Get all players and bullets from the room
  const players = Object.entries(currentRoom.players);
  const bullets = currentRoom.bullets || [];
  
  return (
    <>
      <ambientLight intensity={0.8} />
      <directionalLight position={[5, 5, 5]} intensity={1} />
      
      <Arena />
      
      {players.map(([id, player]) => (
        <Player key={id} playerId={id} player={player} />
      ))}
      
      {bullets.map(bullet => (
        <Bullet key={bullet.id} bullet={bullet} />
      ))}
    </>
  );
}
