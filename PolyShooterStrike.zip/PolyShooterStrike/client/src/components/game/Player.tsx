import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useGameState } from "../../lib/stores/useGameState";
import { usePlayerState } from "../../lib/stores/usePlayerState";
import { useSocketConnection } from "../../lib/stores/useSocketConnection";
import { SocketMessageType, Team, CONSTANTS } from "@shared/game-types";
import Weapons from "./Weapons";

// Player model colors based on team
const TEAM_COLORS = {
  [Team.RED]: "#ff3030",
  [Team.BLUE]: "#4169e1",
  [Team.NONE]: "#adadad"
};

interface PlayerProps {
  id: string;
  isLocal?: boolean;
}

// Player component representing a player in the game
export default function Player({ id, isLocal = false }: PlayerProps) {
  const playerRef = useRef<THREE.Group>(null);
  const bodyRef = useRef<THREE.Mesh>(null);
  const socketConnection = useSocketConnection(state => state.socket);
  const players = useGameState(state => state.currentRoom?.players || {});
  const player = players[id];
  
  const localPlayerState = usePlayerState(state => state);
  
  // Get keyboard controls for local player movement
  const [, getKeys] = useKeyboardControls();
  
  // If player doesn't exist, don't render
  if (!player) return null;
  
  // If player is dead, don't render (or show differently)
  if (!player.isAlive) return null;
  
  // Set up movement for local player
  useEffect(() => {
    if (isLocal && playerRef.current) {
      // Initialize local player position
      localPlayerState.setPosition({
        x: player.position.x,
        y: player.position.y,
        z: player.position.z
      });
      
      console.log("Local player position initialized:", player.position);
    }
  }, [isLocal, player.position.x, player.position.y, player.position.z]);
  
  // Handle player movement
  useFrame((state, delta) => {
    if (isLocal && playerRef.current) {
      const { forward, backward, leftward, rightward, jump, reload, shoot, weapon1, weapon2, weapon3 } = getKeys();
      
      // Get current position
      const currentPosition = { ...localPlayerState.position };
      
      // Handle movement
      const moveSpeed = CONSTANTS.PLAYER_SPEED * delta;
      
      // Calculate movement based on camera direction
      const cameraDirection = new THREE.Vector3();
      state.camera.getWorldDirection(cameraDirection);
      cameraDirection.y = 0;
      cameraDirection.normalize();
      
      // Calculate forward/backward movement
      if (forward) {
        currentPosition.x += cameraDirection.x * moveSpeed;
        currentPosition.z += cameraDirection.z * moveSpeed;
      }
      if (backward) {
        currentPosition.x -= cameraDirection.x * moveSpeed;
        currentPosition.z -= cameraDirection.z * moveSpeed;
      }
      
      // Calculate left/right movement (perpendicular to camera direction)
      const rightVector = new THREE.Vector3();
      rightVector.crossVectors(cameraDirection, new THREE.Vector3(0, 1, 0));
      
      if (rightward) {
        currentPosition.x += rightVector.x * moveSpeed;
        currentPosition.z += rightVector.z * moveSpeed;
      }
      if (leftward) {
        currentPosition.x -= rightVector.x * moveSpeed;
        currentPosition.z -= rightVector.z * moveSpeed;
      }
      
      // Jumping logic - simple jump with gravity
      if (jump && localPlayerState.isGrounded) {
        localPlayerState.setVelocity(CONSTANTS.JUMP_FORCE);
        localPlayerState.setGrounded(false);
      }
      
      // Apply gravity and velocity
      if (!localPlayerState.isGrounded) {
        localPlayerState.setVelocity(localPlayerState.velocity - CONSTANTS.GRAVITY);
        currentPosition.y += localPlayerState.velocity * delta;
        
        // Check if player is back on the ground
        if (currentPosition.y <= 1) {
          currentPosition.y = 1;
          localPlayerState.setGrounded(true);
          localPlayerState.setVelocity(0);
        }
      }
      
      // Apply boundary constraints - keep player within map
      const halfMapSize = CONSTANTS.MAP_SIZE / 2;
      currentPosition.x = Math.max(-halfMapSize, Math.min(halfMapSize, currentPosition.x));
      currentPosition.z = Math.max(-halfMapSize, Math.min(halfMapSize, currentPosition.z));
      
      // Update player's rotation to face direction of movement
      let newRotation = player.rotation;
      if (forward || backward || leftward || rightward) {
        // Calculate angle based on movement direction
        const movementDirection = new THREE.Vector3();
        
        if (forward) movementDirection.add(cameraDirection);
        if (backward) movementDirection.sub(cameraDirection);
        if (rightward) movementDirection.add(rightVector);
        if (leftward) movementDirection.sub(rightVector);
        
        if (movementDirection.length() > 0) {
          movementDirection.normalize();
          newRotation = Math.atan2(movementDirection.x, movementDirection.z);
        }
      }
      
      // Update player state and position
      localPlayerState.setPosition(currentPosition);
      
      // Update server about our position and rotation
      if (socketConnection && localPlayerState.roomId) {
        socketConnection.send(JSON.stringify({
          type: SocketMessageType.PLAYER_MOVE,
          payload: {
            position: currentPosition,
            rotation: newRotation
          }
        }));
      }
      
      // Update player position
      if (playerRef.current) {
        playerRef.current.position.x = currentPosition.x;
        playerRef.current.position.y = currentPosition.y;
        playerRef.current.position.z = currentPosition.z;
        playerRef.current.rotation.y = newRotation;
      }
      
      // Position camera behind player for third-person view
      if (isLocal) {
        const cameraOffset = new THREE.Vector3(
          -Math.sin(newRotation) * 6,
          5,
          -Math.cos(newRotation) * 6
        );
        
        // Smoothly transition camera position
        state.camera.position.lerp(
          new THREE.Vector3(
            currentPosition.x + cameraOffset.x,
            currentPosition.y + cameraOffset.y,
            currentPosition.z + cameraOffset.z
          ),
          0.1
        );
        
        // Look at player
        state.camera.lookAt(
          currentPosition.x,
          currentPosition.y + 1.5, // Look at head level
          currentPosition.z
        );
      }
      
      // Handle weapon switching
      if (weapon1) {
        localPlayerState.changeWeapon(0);
      } else if (weapon2) {
        localPlayerState.changeWeapon(1);
      } else if (weapon3) {
        localPlayerState.changeWeapon(2);
      }
      
      // Handle reloading
      if (reload) {
        localPlayerState.reload();
      }
      
      // Handle shooting
      if (shoot) {
        localPlayerState.shoot();
      }
    } else if (!isLocal && playerRef.current) {
      // For remote players, just update position and rotation from server
      playerRef.current.position.x = player.position.x;
      playerRef.current.position.y = player.position.y;
      playerRef.current.position.z = player.position.z;
      playerRef.current.rotation.y = player.rotation;
    }
  });
  
  // Get color based on team
  const teamColor = TEAM_COLORS[player.team];
  
  return (
    <group ref={playerRef} position={[player.position.x, player.position.y, player.position.z]} rotation={[0, player.rotation, 0]}>
      {/* Player body */}
      <mesh ref={bodyRef} castShadow receiveShadow>
        <capsuleGeometry args={[0.5, 1, 4, 8]} />
        <meshStandardMaterial color={teamColor} />
      </mesh>
      
      {/* Player head */}
      <mesh position={[0, 1.1, 0]} castShadow>
        <sphereGeometry args={[0.4, 16, 16]} />
        <meshStandardMaterial color={teamColor} />
      </mesh>
      
      {/* Player weapon */}
      <Weapons 
        weaponType={player.currentWeapon} 
        isReloading={player.isReloading}
        isLocal={isLocal}
      />
      
      {/* Player name tag */}
      <group position={[0, 2, 0]}>
        <Billboard>
          <Text 
            position={[0, 0, 0]}
            color={isLocal ? "#00ff00" : "#ffffff"}
            fontSize={0.3}
            anchorX="center"
            anchorY="middle"
          >
            {player.username}
          </Text>
        </Billboard>
      </group>
    </group>
  );
}

// Import these components to avoid errors
import { Billboard, Text } from "@react-three/drei";
