import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";
import { WeaponType } from "@shared/game-types";

interface BulletProps {
  position: { x: number; y: number; z: number };
  direction: { x: number; y: number; z: number };
  weaponType: WeaponType;
}

export default function Bullet({ position, direction, weaponType }: BulletProps) {
  const bulletRef = useRef<THREE.Mesh>(null);
  const trailRef = useRef<THREE.Mesh>(null);
  
  // Define bullet appearance based on weapon type
  let bulletSize = 0.1;
  let bulletColor = "#ffff00";
  
  switch (weaponType) {
    case WeaponType.PISTOL:
      bulletSize = 0.1;
      bulletColor = "#ffff00";
      break;
    case WeaponType.RIFLE:
      bulletSize = 0.08;
      bulletColor = "#ff9900";
      break;
    case WeaponType.SHOTGUN:
      bulletSize = 0.12;
      bulletColor = "#ff0000";
      break;
    default:
      bulletSize = 0.1;
      bulletColor = "#ffff00";
      break;
  }
  
  // Initialize bullet and trail position
  useFrame(() => {
    if (bulletRef.current) {
      bulletRef.current.position.set(position.x, position.y, position.z);
    }
    
    if (trailRef.current) {
      trailRef.current.position.set(position.x, position.y, position.z);
      
      // Point trail in the direction of movement
      trailRef.current.lookAt(
        position.x - direction.x,
        position.y - direction.y,
        position.z - direction.z
      );
    }
  });
  
  return (
    <group>
      {/* Bullet mesh */}
      <mesh ref={bulletRef} position={[position.x, position.y, position.z]}>
        <sphereGeometry args={[bulletSize, 8, 8]} />
        <meshStandardMaterial emissive={bulletColor} emissiveIntensity={2} />
      </mesh>
      
      {/* Bullet trail */}
      <mesh ref={trailRef} position={[position.x, position.y, position.z]}>
        <planeGeometry args={[0.05, 2]} />
        <meshBasicMaterial 
          color={bulletColor} 
          opacity={0.7} 
          transparent={true} 
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}
