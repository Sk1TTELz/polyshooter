import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { WeaponType } from "@shared/game-types";

interface WeaponsProps {
  weaponType: WeaponType;
  isReloading: boolean;
  isLocal: boolean;
}

export default function Weapons({ weaponType, isReloading, isLocal }: WeaponsProps) {
  const weaponRef = useRef<THREE.Group>(null);
  
  // Define different weapon shapes and colors
  const weaponGeometry = useMemo(() => {
    switch (weaponType) {
      case WeaponType.PISTOL:
        return {
          body: new THREE.BoxGeometry(0.1, 0.2, 0.4),
          barrel: new THREE.BoxGeometry(0.06, 0.06, 0.4),
          color: "#555555"
        };
      case WeaponType.RIFLE:
        return {
          body: new THREE.BoxGeometry(0.1, 0.2, 0.6),
          barrel: new THREE.BoxGeometry(0.06, 0.06, 0.8),
          color: "#333333"
        };
      case WeaponType.SHOTGUN:
        return {
          body: new THREE.BoxGeometry(0.12, 0.2, 0.5),
          barrel: new THREE.BoxGeometry(0.09, 0.09, 0.7),
          color: "#5b4421"
        };
      default:
        return {
          body: new THREE.BoxGeometry(0.1, 0.2, 0.4),
          barrel: new THREE.BoxGeometry(0.06, 0.06, 0.4),
          color: "#555555"
        };
    }
  }, [weaponType]);
  
  // Handle weapon animation when reloading
  useFrame((_, delta) => {
    if (weaponRef.current && isReloading) {
      // Rotate weapon during reload animation
      weaponRef.current.rotation.z = Math.sin(Date.now() * 0.01) * 0.5;
    } else if (weaponRef.current) {
      // Reset rotation when not reloading
      weaponRef.current.rotation.z = THREE.MathUtils.lerp(
        weaponRef.current.rotation.z,
        0,
        delta * 5
      );
    }
  });
  
  // Position the weapon differently based on whether it's the local player or not
  const position: [number, number, number] = isLocal 
    ? [0.6, 0.2, 0] // Right side for local player
    : [0.5, 0.0, 0.5]; // For other players
  
  return (
    <group ref={weaponRef} position={position} rotation={[0, 0, 0]}>
      {/* Weapon body */}
      <mesh castShadow>
        <boxGeometry args={[weaponGeometry.body.parameters.width, weaponGeometry.body.parameters.height, weaponGeometry.body.parameters.depth]} />
        <meshStandardMaterial color={weaponGeometry.color} />
      </mesh>
      
      {/* Weapon barrel */}
      <mesh position={[0, 0, -weaponGeometry.barrel.parameters.depth / 2 - 0.1]} castShadow>
        <boxGeometry args={[weaponGeometry.barrel.parameters.width, weaponGeometry.barrel.parameters.height, weaponGeometry.barrel.parameters.depth]} />
        <meshStandardMaterial color={weaponGeometry.color} />
      </mesh>
      
      {/* Weapon handle */}
      <mesh position={[0, -0.25, 0.1]} castShadow>
        <boxGeometry args={[0.08, 0.3, 0.12]} />
        <meshStandardMaterial color="#333333" />
      </mesh>
    </group>
  );
}
