import React, { useState, useEffect } from "react";
import { useAudio } from "../../lib/stores/useAudio";
import { useGameState } from "../../lib/stores/useGameState";
import { useSocketConnection } from "../../lib/stores/useSocketConnection";
import { Button } from "../ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "../ui/card";
import { Input } from "../ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Separator } from "../ui/separator";
import { GameMode, SocketMessageType, IGameRoom } from "@shared/game-types";
import TeamSelection from "./team-selection";

// Lobby component for game room management
export default function Lobby() {
  const [username, setUsername] = useState(() => {
    // Try to get username from localStorage
    const stored = localStorage.getItem("username");
    return stored || `Player${Math.floor(Math.random() * 1000)}`;
  });
  
  const [roomName, setRoomName] = useState(`Game ${Math.floor(Math.random() * 1000)}`);
  const [selectedGameMode, setSelectedGameMode] = useState<GameMode>(GameMode.FREE_FOR_ALL);
  const [activeTab, setActiveTab] = useState("join");
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  
  const { connectSocket, socket } = useSocketConnection();
  const { roomsList, currentRoom, playerId, fetchRooms, joinRoom, createRoom } = useGameState();
  const { backgroundMusic, toggleMute, isMuted } = useAudio();
  
  // Connect to WebSocket on component mount
  useEffect(() => {
    if (!socket) {
      connectSocket();
    }
    
    // Save username to localStorage
    localStorage.setItem("username", username);
    
    // Start background music
    if (backgroundMusic) {
      backgroundMusic.play().catch(err => {
        console.log("Background music autoplay prevented:", err);
      });
    }
    
    // Cleanup on unmount
    return () => {
      if (backgroundMusic) {
        backgroundMusic.pause();
        backgroundMusic.currentTime = 0;
      }
    };
  }, [connectSocket, socket, username, backgroundMusic]);
  
  // Refresh rooms list every 5 seconds
  useEffect(() => {
    fetchRooms();
    const interval = setInterval(fetchRooms, 5000);
    
    return () => clearInterval(interval);
  }, [fetchRooms]);
  
  const handleCreateRoom = () => {
    if (!username.trim() || !roomName.trim()) {
      alert("Please enter a username and room name");
      return;
    }
    
    createRoom(roomName, selectedGameMode, username);
  };
  
  const handleJoinRoom = () => {
    if (!selectedRoomId) {
      alert("Please select a room to join");
      return;
    }
    
    if (!username.trim()) {
      alert("Please enter a username");
      return;
    }
    
    joinRoom(selectedRoomId, username);
  };
  
  const handleLeaveRoom = () => {
    if (socket && currentRoom) {
      socket.send(JSON.stringify({
        type: SocketMessageType.LEAVE_ROOM
      }));
    }
  };
  
  const handleStartGame = () => {
    if (socket && currentRoom) {
      socket.send(JSON.stringify({
        type: SocketMessageType.START_GAME
      }));
    }
  };
  
  // Filter rooms to show only those that aren't full and in LOBBY state
  const availableRooms = roomsList.filter(
    room => Object.keys(room.players).length < room.maxPlayers && room.status === "LOBBY"
  );
  
  return (
    <div className="min-h-screen w-full bg-gray-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-gray-800 text-white">
        <CardHeader className="bg-gray-700 rounded-t-lg flex flex-row items-center justify-between">
          <CardTitle className="text-2xl">Low-Poly Shooter</CardTitle>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMute}
              title={isMuted ? "Unmute" : "Mute"}
            >
              <i className={`fa ${isMuted ? 'fa-volume-mute' : 'fa-volume-up'}`}></i>
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {currentRoom ? (
            <RoomView 
              room={currentRoom} 
              playerId={playerId || ""} 
              onLeave={handleLeaveRoom} 
              onStart={handleStartGame}
            />
          ) : (
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6 bg-gray-700">
                <TabsTrigger value="join">Join Game</TabsTrigger>
                <TabsTrigger value="create">Create Game</TabsTrigger>
              </TabsList>
              
              <TabsContent value="join" className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Your Name
                  </label>
                  <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter your name"
                    className="bg-gray-700"
                  />
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Available Rooms</h3>
                  {availableRooms.length === 0 ? (
                    <div className="text-gray-400 text-center py-8">
                      No rooms available. Create a new room to play!
                    </div>
                  ) : (
                    <div className="max-h-64 overflow-y-auto space-y-2">
                      {availableRooms.map(room => (
                        <div
                          key={room.id}
                          className={`p-3 rounded cursor-pointer transition-colors ${
                            selectedRoomId === room.id ? 'bg-blue-900' : 'bg-gray-700 hover:bg-gray-600'
                          }`}
                          onClick={() => setSelectedRoomId(room.id)}
                        >
                          <div className="flex justify-between">
                            <div className="font-medium">{room.name}</div>
                            <div className="text-sm text-gray-300">
                              {Object.keys(room.players).length}/{room.maxPlayers} players
                            </div>
                          </div>
                          <div className="text-sm text-gray-400 mt-1">
                            {room.mode === GameMode.FREE_FOR_ALL ? "Free For All" : "Team Deathmatch"}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <Button 
                  onClick={handleJoinRoom} 
                  disabled={!selectedRoomId} 
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  Join Selected Room
                </Button>
              </TabsContent>
              
              <TabsContent value="create" className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Your Name
                  </label>
                  <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter your name"
                    className="bg-gray-700"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Room Name
                  </label>
                  <Input
                    value={roomName}
                    onChange={(e) => setRoomName(e.target.value)}
                    placeholder="Enter room name"
                    className="bg-gray-700"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Game Mode
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    <div
                      className={`p-4 rounded cursor-pointer text-center ${
                        selectedGameMode === GameMode.FREE_FOR_ALL 
                          ? 'bg-blue-900' 
                          : 'bg-gray-700 hover:bg-gray-600'
                      }`}
                      onClick={() => setSelectedGameMode(GameMode.FREE_FOR_ALL)}
                    >
                      <div className="text-lg font-medium">Free For All</div>
                      <div className="text-sm text-gray-300 mt-1">
                        Every player for themselves
                      </div>
                    </div>
                    <div
                      className={`p-4 rounded cursor-pointer text-center ${
                        selectedGameMode === GameMode.TEAM_DEATHMATCH 
                          ? 'bg-blue-900' 
                          : 'bg-gray-700 hover:bg-gray-600'
                      }`}
                      onClick={() => setSelectedGameMode(GameMode.TEAM_DEATHMATCH)}
                    >
                      <div className="text-lg font-medium">Team Deathmatch</div>
                      <div className="text-sm text-gray-300 mt-1">
                        Red vs Blue teams
                      </div>
                    </div>
                  </div>
                </div>
                
                <Button 
                  onClick={handleCreateRoom} 
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  Create Room
                </Button>
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
        <CardFooter className="bg-gray-700 rounded-b-lg text-sm text-gray-300">
          <div>Use WASD to move, Space to jump, Mouse to aim and shoot</div>
        </CardFooter>
      </Card>
    </div>
  );
}

// Room view component for when player is in a room
function RoomView({ 
  room, 
  playerId, 
  onLeave, 
  onStart 
}: { 
  room: IGameRoom, 
  playerId: string, 
  onLeave: () => void, 
  onStart: () => void 
}) {
  const players = Object.values(room.players);
  const isHost = players[0]?.id === playerId;
  
  // Check if we have enough players to start
  const canStart = players.length >= 2;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">{room.name}</h2>
        <div className="text-sm text-gray-300">
          {room.mode === GameMode.FREE_FOR_ALL ? "Free For All" : "Team Deathmatch"}
        </div>
      </div>
      
      <Separator />
      
      {room.mode === GameMode.TEAM_DEATHMATCH && (
        <TeamSelection room={room} playerId={playerId} />
      )}
      
      <div>
        <h3 className="text-lg font-semibold mb-2">Players ({players.length}/{room.maxPlayers})</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {players.map(player => (
            <div
              key={player.id}
              className={`p-3 rounded ${
                player.id === playerId ? 'bg-blue-900' : 'bg-gray-700'
              }`}
            >
              <div className="flex items-center">
                <div className="font-medium">{player.username}</div>
                {player.id === playerId && (
                  <span className="ml-2 text-xs bg-green-700 px-2 py-1 rounded">You</span>
                )}
                {players[0]?.id === player.id && (
                  <span className="ml-2 text-xs bg-yellow-700 px-2 py-1 rounded">Host</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <Button 
          onClick={onLeave} 
          variant="destructive"
          className="w-full sm:w-auto"
        >
          Leave Room
        </Button>
        
        <div className="text-sm text-gray-300 flex items-center">
          {!canStart && isHost && "Need at least 2 players to start"}
          {!isHost && "Waiting for host to start the game"}
        </div>
        
        {isHost && (
          <Button 
            onClick={onStart} 
            disabled={!canStart}
            className="w-full sm:w-auto bg-green-600 hover:bg-green-700 disabled:bg-gray-600"
          >
            Start Game
          </Button>
        )}
      </div>
      
      <div className="mt-4 bg-gray-900 p-3 rounded text-sm">
        <div className="font-semibold mb-1">Share this link with your friends:</div>
        <div className="flex gap-2">
          <Input
            readOnly
            value={`${window.location.origin}?room=${room.id}`}
            className="bg-gray-800"
          />
          <Button
            onClick={() => {
              navigator.clipboard.writeText(`${window.location.origin}?room=${room.id}`);
              alert("Link copied to clipboard!");
            }}
            variant="outline"
          >
            Copy
          </Button>
        </div>
      </div>
    </div>
  );
}
