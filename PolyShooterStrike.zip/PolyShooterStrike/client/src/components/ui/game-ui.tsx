import React, { useEffect, useState } from "react";
import { useAudio } from "../../lib/stores/useAudio";
import { useGameState } from "../../lib/stores/useGameState";
import { usePlayerState } from "../../lib/stores/usePlayerState";
import { Team, WeaponType, CONSTANTS } from "@shared/game-types";

export default function GameUI() {
  const { currentRoom, playerId } = useGameState(state => ({
    currentRoom: state.currentRoom,
    playerId: state.playerId
  }));
  
  const { toggleMute, isMuted } = useAudio();
  const { selectedWeaponIndex, isReloading, ammo, reload } = usePlayerState();
  
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes game time
  const [showScoreboard, setShowScoreboard] = useState(false);
  
  useEffect(() => {
    // Set up game timer
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Handle scoreboard toggle with Tab key
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Tab") {
        e.preventDefault();
        setShowScoreboard(true);
      }
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Tab") {
        e.preventDefault();
        setShowScoreboard(false);
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    
    return () => {
      clearInterval(timer);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);
  
  if (!currentRoom || !playerId) return null;
  
  const player = currentRoom.players[playerId];
  if (!player) return null;
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };
  
  // Get weapon name
  const getWeaponName = (type: WeaponType) => {
    switch (type) {
      case WeaponType.PISTOL: return "Pistol";
      case WeaponType.RIFLE: return "Rifle";
      case WeaponType.SHOTGUN: return "Shotgun";
      default: return "Unknown";
    }
  };
  
  // Calculate team scores for team deathmatch
  const teamScores = {
    [Team.RED]: 0,
    [Team.BLUE]: 0
  };
  
  if (currentRoom.mode === "TEAM_DEATHMATCH") {
    Object.values(currentRoom.players).forEach(p => {
      if (p.team === Team.RED) {
        teamScores[Team.RED] += p.score;
      } else if (p.team === Team.BLUE) {
        teamScores[Team.BLUE] += p.score;
      }
    });
  }
  
  return (
    <div className="fixed inset-0 pointer-events-none">
      {/* Health bar */}
      <div className="absolute bottom-6 left-6 bg-black bg-opacity-50 p-2 rounded-lg">
        <div className="text-white text-sm font-bold mb-1">Health</div>
        <div className="w-48 h-4 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-red-600 rounded-full"
            style={{ width: `${player.health}%` }}
          />
        </div>
      </div>
      
      {/* Weapon and ammo */}
      <div className="absolute bottom-6 right-6 bg-black bg-opacity-50 p-2 rounded-lg">
        <div className="text-white text-sm font-bold mb-1 flex justify-between">
          <span>{getWeaponName(player.currentWeapon)}</span>
          {isReloading && <span className="text-yellow-400">Reloading...</span>}
        </div>
        <div className="flex gap-1">
          {[WeaponType.PISTOL, WeaponType.RIFLE, WeaponType.SHOTGUN].map((weapon, index) => (
            <div 
              key={weapon}
              className={`w-12 h-8 ${selectedWeaponIndex === index ? 'bg-blue-600' : 'bg-gray-700'} rounded flex items-center justify-center text-white cursor-pointer`}
              onClick={() => usePlayerState.getState().changeWeapon(index)}
              style={{ pointerEvents: 'auto' }}
            >
              {index + 1}
            </div>
          ))}
        </div>
        <div className="mt-1 text-right text-white text-lg font-bold">
          {ammo} / {CONSTANTS.WEAPONS[player.currentWeapon].ammoCapacity}
        </div>
      </div>
      
      {/* Timer and score */}
      <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 px-4 py-2 rounded-lg flex items-center gap-6">
        {/* Game mode */}
        <div className="text-white font-bold">
          {currentRoom.mode === "TEAM_DEATHMATCH" ? "Team Deathmatch" : "Free For All"}
        </div>
        
        {/* Timer */}
        <div className="text-white text-xl font-bold">
          {formatTime(timeLeft)}
        </div>
        
        {/* Scores for team deathmatch */}
        {currentRoom.mode === "TEAM_DEATHMATCH" && (
          <div className="flex gap-4">
            <div className="px-3 py-1 bg-red-700 text-white rounded font-bold">
              Red: {teamScores[Team.RED]}
            </div>
            <div className="px-3 py-1 bg-blue-700 text-white rounded font-bold">
              Blue: {teamScores[Team.BLUE]}
            </div>
          </div>
        )}
        
        {/* Score for free-for-all */}
        {currentRoom.mode === "FREE_FOR_ALL" && (
          <div className="text-white font-bold">
            Score: {player.score}
          </div>
        )}
      </div>
      
      {/* Sound toggle button */}
      <button
        className="absolute top-6 right-6 bg-black bg-opacity-50 p-2 rounded-lg text-white hover:bg-opacity-70 transition-all"
        onClick={toggleMute}
        style={{ pointerEvents: 'auto' }}
      >
        <i className={`fa ${isMuted ? 'fa-volume-mute' : 'fa-volume-up'}`}></i>
      </button>
      
      {/* Reload button */}
      <button
        className="absolute bottom-24 right-6 bg-black bg-opacity-50 px-4 py-2 rounded-lg text-white hover:bg-opacity-70 transition-all"
        onClick={reload}
        disabled={isReloading}
        style={{ pointerEvents: 'auto' }}
      >
        Reload (R)
      </button>
      
      {/* Crosshair */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-2xl">
        +
      </div>
      
      {/* Scoreboard */}
      {showScoreboard && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-80 p-4 rounded-lg w-2/3 max-w-3xl">
          <h2 className="text-white text-2xl font-bold mb-4 text-center">Scoreboard</h2>
          
          <table className="w-full text-white">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left p-2">Player</th>
                <th className="text-center p-2">Team</th>
                <th className="text-center p-2">Kills</th>
                <th className="text-right p-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {Object.values(currentRoom.players)
                .sort((a, b) => b.score - a.score)
                .map(p => (
                  <tr key={p.id} className={`${p.id === playerId ? 'bg-blue-900 bg-opacity-50' : ''}`}>
                    <td className="text-left p-2">{p.username}</td>
                    <td className="text-center p-2">
                      {p.team === Team.RED && <span className="text-red-500">Red</span>}
                      {p.team === Team.BLUE && <span className="text-blue-500">Blue</span>}
                      {p.team === Team.NONE && <span className="text-gray-400">-</span>}
                    </td>
                    <td className="text-center p-2">{p.score}</td>
                    <td className="text-right p-2">
                      {p.isAlive ? (
                        <span className="text-green-500">Alive</span>
                      ) : (
                        <span className="text-red-500">Dead</span>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Game instructions */}
      <div className="absolute top-24 right-6 bg-black bg-opacity-50 p-3 rounded-lg text-white text-sm">
        <div className="font-bold mb-1">Controls:</div>
        <div>WASD - Move</div>
        <div>Space - Jump</div>
        <div>Left Click - Shoot</div>
        <div>R - Reload</div>
        <div>1,2,3 - Switch Weapons</div>
        <div>Tab - Scoreboard</div>
      </div>
    </div>
  );
}
