import React from "react";
import { Button } from "../ui/button";
import { IGameRoom, Team, SocketMessageType } from "@shared/game-types";
import { useSocketConnection } from "../../lib/stores/useSocketConnection";

interface TeamSelectionProps {
  room: IGameRoom;
  playerId: string;
}

export default function TeamSelection({ room, playerId }: TeamSelectionProps) {
  const socket = useSocketConnection(state => state.socket);
  
  // Get player teams
  const redTeam = room.teams?.[Team.RED] || [];
  const blueTeam = room.teams?.[Team.BLUE] || [];
  
  // Get current player's team
  const currentTeam = room.players[playerId]?.team;
  
  // Change team handler
  const handleChangeTeam = (team: Team) => {
    if (!socket || currentTeam === team) return;
    
    socket.send(JSON.stringify({
      type: SocketMessageType.CHANGE_TEAM,
      payload: { team }
    }));
  };
  
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Select Your Team</h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Red Team */}
        <div className={`p-4 rounded border-2 ${currentTeam === Team.RED ? 'border-red-500' : 'border-transparent'}`}>
          <div className="flex justify-between items-center mb-2">
            <h4 className="text-red-500 font-bold">Red Team</h4>
            <span className="text-sm text-gray-300">{redTeam.length} players</span>
          </div>
          
          <div className="max-h-40 overflow-y-auto space-y-1 mb-3">
            {redTeam.map(id => (
              <div 
                key={id} 
                className={`p-2 rounded bg-gray-700 ${id === playerId ? 'border-l-4 border-red-500' : ''}`}
              >
                {room.players[id]?.username}
                {id === playerId && <span className="ml-2 text-xs">(You)</span>}
              </div>
            ))}
            {redTeam.length === 0 && (
              <div className="text-gray-400 text-center py-2">No players yet</div>
            )}
          </div>
          
          <Button
            onClick={() => handleChangeTeam(Team.RED)}
            disabled={currentTeam === Team.RED}
            className="w-full bg-red-800 hover:bg-red-700 disabled:bg-gray-700"
          >
            {currentTeam === Team.RED ? "Current Team" : "Join Red Team"}
          </Button>
        </div>
        
        {/* Blue Team */}
        <div className={`p-4 rounded border-2 ${currentTeam === Team.BLUE ? 'border-blue-500' : 'border-transparent'}`}>
          <div className="flex justify-between items-center mb-2">
            <h4 className="text-blue-500 font-bold">Blue Team</h4>
            <span className="text-sm text-gray-300">{blueTeam.length} players</span>
          </div>
          
          <div className="max-h-40 overflow-y-auto space-y-1 mb-3">
            {blueTeam.map(id => (
              <div 
                key={id} 
                className={`p-2 rounded bg-gray-700 ${id === playerId ? 'border-l-4 border-blue-500' : ''}`}
              >
                {room.players[id]?.username}
                {id === playerId && <span className="ml-2 text-xs">(You)</span>}
              </div>
            ))}
            {blueTeam.length === 0 && (
              <div className="text-gray-400 text-center py-2">No players yet</div>
            )}
          </div>
          
          <Button
            onClick={() => handleChangeTeam(Team.BLUE)}
            disabled={currentTeam === Team.BLUE}
            className="w-full bg-blue-800 hover:bg-blue-700 disabled:bg-gray-700"
          >
            {currentTeam === Team.BLUE ? "Current Team" : "Join Blue Team"}
          </Button>
        </div>
      </div>
    </div>
  );
}
