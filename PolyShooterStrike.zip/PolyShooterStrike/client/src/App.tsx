import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect } from "react";
import { KeyboardControls } from "@react-three/drei";
import { QueryClientProvider } from "@tanstack/react-query";
import { useAudio } from "./lib/stores/useAudio";
import { useGameState } from "./lib/stores/useGameState";
import { useSocketConnection } from "./lib/stores/useSocketConnection";
import { GameStatus } from "@shared/game-types";
import { queryClient } from "./lib/queryClient";
import World from "./components/game/World";
import Lobby from "./components/ui/lobby";
import GameUI from "./components/ui/game-ui";
import "@fontsource/inter";

const controls = [
  { name: "forward", keys: ["KeyW", "ArrowUp"] },
  { name: "backward", keys: ["KeyS", "ArrowDown"] },
  { name: "leftward", keys: ["KeyA", "ArrowLeft"] },
  { name: "rightward", keys: ["KeyD", "ArrowRight"] },
  { name: "jump", keys: ["Space"] },
  { name: "shoot", keys: ["Mouse0"] },
  { name: "reload", keys: ["KeyR"] },
  { name: "weapon1", keys: ["Digit1"] },
  { name: "weapon2", keys: ["Digit2"] },
  { name: "weapon3", keys: ["Digit3"] },
];

function SoundManager() {
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    const hit = new Audio("/sounds/hit.mp3");
    hit.volume = 0.4;
    setHitSound(hit);

    const success = new Audio("/sounds/success.mp3");
    success.volume = 0.5;
    setSuccessSound(success);

    return () => {
      bgMusic.pause();
      bgMusic.currentTime = 0;
    };
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  return null;
}

function App() {
  const gameStatus = useGameState(state => state.status);
  const isLoading = useGameState(state => state.isLoading);

  useEffect(() => {
    const socketState = useSocketConnection.getState();
    if (!socketState.socket || !socketState.isConnected) {
      socketState.connectSocket();
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="w-screen h-screen overflow-hidden relative">
        {gameStatus === GameStatus.LOBBY && <Lobby />}

        {gameStatus === GameStatus.PLAYING && (
          <div className="w-full h-full relative">
            <KeyboardControls map={controls}>
              <Canvas shadows camera={{ position: [0, 5, 10], fov: 60 }}>
                <Suspense fallback={null}>
                  <World />
                </Suspense>
              </Canvas>
              <GameUI />
            </KeyboardControls>
          </div>
        )}

        {gameStatus === GameStatus.ENDED && (
          <div className="h-screen w-screen flex flex-col items-center justify-center bg-gray-900 text-white">
            <h1 className="text-4xl mb-4">Game Over</h1>
            <button 
              className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
              onClick={() => useGameState.getState().returnToLobby()}
            >
              Return to Lobby
            </button>
          </div>
        )}

        <SoundManager />
      </div>
    </QueryClientProvider>
  );
}

export default App;