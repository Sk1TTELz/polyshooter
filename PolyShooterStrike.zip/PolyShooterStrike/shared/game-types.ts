// Game mode types
export enum GameMode {
  FREE_FOR_ALL = "FREE_FOR_ALL",
  TEAM_DEATHMATCH = "TEAM_DEATHMATCH"
}

// Team types
export enum Team {
  RED = "RED",
  BLUE = "BLUE",
  NONE = "NONE" // For free-for-all mode
}

// Weapon types
export enum WeaponType {
  PISTOL = "PISTOL",
  RIFLE = "RIFLE",
  SHOTGUN = "SHOTGUN"
}

// Game state types
export enum GameStatus {
  LOBBY = "LOBBY",
  PLAYING = "PLAYING",
  ENDED = "ENDED"
}

// Player interface
export interface IPlayer {
  id: string;
  username: string;
  position: Vector3;
  rotation: number;
  health: number;
  team: Team;
  currentWeapon: WeaponType;
  score: number;
  isAlive: boolean;
  isReloading: boolean;
  lastShootTime: number;
}

// Bullet interface
export interface IBullet {
  id: string;
  position: Vector3;
  direction: Vector3;
  speed: number;
  ownerId: string;
  damage: number;
  weaponType: WeaponType;
  createdAt: number;
}

// Vector3 interface for 3D positions
export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

// Game room interface
export interface IGameRoom {
  id: string;
  name: string;
  mode: GameMode;
  status: GameStatus;
  players: Record<string, IPlayer>;
  bullets: IBullet[];
  maxPlayers: number;
  createdAt: number;
  teams?: {
    [Team.RED]: string[]; // Array of player IDs
    [Team.BLUE]: string[]; // Array of player IDs
  };
}

// Weapon stats
export interface WeaponStats {
  damage: number;
  fireRate: number; // Shots per second
  reloadTime: number; // Seconds
  ammoCapacity: number;
  spread: number; // Accuracy (lower is better)
  bulletSpeed: number;
  automatic: boolean;
}

// Socket message types
export enum SocketMessageType {
  // Client to server
  JOIN_ROOM = "JOIN_ROOM",
  CREATE_ROOM = "CREATE_ROOM",
  LEAVE_ROOM = "LEAVE_ROOM",
  PLAYER_MOVE = "PLAYER_MOVE",
  PLAYER_ROTATE = "PLAYER_ROTATE",
  PLAYER_SHOOT = "PLAYER_SHOOT",
  PLAYER_RELOAD = "PLAYER_RELOAD",
  PLAYER_SWITCH_WEAPON = "PLAYER_SWITCH_WEAPON",
  PLAYER_JUMP = "PLAYER_JUMP",
  CHANGE_TEAM = "CHANGE_TEAM",
  START_GAME = "START_GAME",
  RESTART_GAME = "RESTART_GAME",
  END_GAME = "END_GAME",
  
  // Server to client
  ROOMS_LIST = "ROOMS_LIST",
  ROOM_JOINED = "ROOM_JOINED",
  ROOM_UPDATE = "ROOM_UPDATE",
  GAME_STARTED = "GAME_STARTED",
  GAME_ENDED = "GAME_ENDED",
  PLAYER_HIT = "PLAYER_HIT",
  PLAYER_DIED = "PLAYER_DIED",
  PLAYER_RESPAWNED = "PLAYER_RESPAWNED",
  ERROR = "ERROR"
}

// Constants
export const CONSTANTS = {
  PLAYER_SPEED: 5,
  JUMP_FORCE: 8,
  GRAVITY: 0.2,
  MAX_HEALTH: 100,
  RESPAWN_TIME: 3000, // ms
  BULLET_LIFETIME: 3000, // ms
  MAP_SIZE: 50,
  WEAPONS: {
    [WeaponType.PISTOL]: {
      damage: 20,
      fireRate: 2,
      reloadTime: 1.5,
      ammoCapacity: 8,
      spread: 0.05,
      bulletSpeed: 20,
      automatic: false
    },
    [WeaponType.RIFLE]: {
      damage: 15,
      fireRate: 8,
      reloadTime: 2.5,
      ammoCapacity: 30,
      spread: 0.08,
      bulletSpeed: 25,
      automatic: true
    },
    [WeaponType.SHOTGUN]: {
      damage: 8, // Per pellet, usually fires multiple
      fireRate: 1,
      reloadTime: 3,
      ammoCapacity: 6,
      spread: 0.15,
      bulletSpeed: 15,
      automatic: false
    }
  }
};
